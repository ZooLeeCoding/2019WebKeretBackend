module.exports = {
    "pista": "12345",
    "ocean": "man",
    "alma": "gomba",
    "pelda": "peter"
}

//hasznalat pl. tomb["pista"]